/* Default js file for XNAT "Default" theme */

// This script will be loaded automatically on every page load.
// Other scripts that are theme-specific should go in its 'scripts'
// folder and be loaded from there.

console.log('theme: xnat-sample');
